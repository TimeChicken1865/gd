package net.mcreator.cickennuggetacsopupgradesmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.cickennuggetacsopupgradesmod.entity.BeamA11Entity;
import net.mcreator.cickennuggetacsopupgradesmod.client.model.ModelBeam;

public class BeamA11Renderer extends MobRenderer<BeamA11Entity, ModelBeam<BeamA11Entity>> {
	public BeamA11Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelBeam(context.bakeLayer(ModelBeam.LAYER_LOCATION)), 10f);
		this.addLayer(new EyesLayer<BeamA11Entity, ModelBeam<BeamA11Entity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("cickennuggetacs_op_upgrades_mod:textures/fire.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(BeamA11Entity entity) {
		return new ResourceLocation("cickennuggetacs_op_upgrades_mod:textures/invis.png");
	}
}
