package net.mcreator.cickennuggetacsopupgradesmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.cickennuggetacsopupgradesmod.entity.BeamA14Entity;
import net.mcreator.cickennuggetacsopupgradesmod.client.model.ModelBeam4;

public class BeamA14Renderer extends MobRenderer<BeamA14Entity, ModelBeam4<BeamA14Entity>> {
	public BeamA14Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelBeam4(context.bakeLayer(ModelBeam4.LAYER_LOCATION)), 10f);
		this.addLayer(new EyesLayer<BeamA14Entity, ModelBeam4<BeamA14Entity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("cickennuggetacs_op_upgrades_mod:textures/fire.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(BeamA14Entity entity) {
		return new ResourceLocation("cickennuggetacs_op_upgrades_mod:textures/invis.png");
	}
}
