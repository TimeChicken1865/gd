package net.mcreator.cickennuggetacsopupgradesmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.cickennuggetacsopupgradesmod.entity.FireeeeEntity;
import net.mcreator.cickennuggetacsopupgradesmod.client.model.ModelFS1;

public class FireeeeRenderer extends MobRenderer<FireeeeEntity, ModelFS1<FireeeeEntity>> {
	public FireeeeRenderer(EntityRendererProvider.Context context) {
		super(context, new ModelFS1(context.bakeLayer(ModelFS1.LAYER_LOCATION)), 0f);
		this.addLayer(new EyesLayer<FireeeeEntity, ModelFS1<FireeeeEntity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("cickennuggetacs_op_upgrades_mod:textures/fire.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(FireeeeEntity entity) {
		return new ResourceLocation("cickennuggetacs_op_upgrades_mod:textures/invis.png");
	}
}
