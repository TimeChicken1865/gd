package net.mcreator.cickennuggetacsopupgradesmod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.RenderType;

import net.mcreator.cickennuggetacsopupgradesmod.entity.BeamA13Entity;
import net.mcreator.cickennuggetacsopupgradesmod.client.model.ModelBeam3;

public class BeamA13Renderer extends MobRenderer<BeamA13Entity, ModelBeam3<BeamA13Entity>> {
	public BeamA13Renderer(EntityRendererProvider.Context context) {
		super(context, new ModelBeam3(context.bakeLayer(ModelBeam3.LAYER_LOCATION)), 10f);
		this.addLayer(new EyesLayer<BeamA13Entity, ModelBeam3<BeamA13Entity>>(this) {
			@Override
			public RenderType renderType() {
				return RenderType.eyes(new ResourceLocation("cickennuggetacs_op_upgrades_mod:textures/fire.png"));
			}
		});
	}

	@Override
	public ResourceLocation getTextureLocation(BeamA13Entity entity) {
		return new ResourceLocation("cickennuggetacs_op_upgrades_mod:textures/invis.png");
	}
}
