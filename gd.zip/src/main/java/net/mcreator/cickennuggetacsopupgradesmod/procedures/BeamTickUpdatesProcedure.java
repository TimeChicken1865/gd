package net.mcreator.cickennuggetacsopupgradesmod.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.server.level.ServerLevel;

import net.mcreator.cickennuggetacsopupgradesmod.network.CickennuggetacsOpUpgradesModModVariables;
import net.mcreator.cickennuggetacsopupgradesmod.init.CickennuggetacsOpUpgradesModModEntities;
import net.mcreator.cickennuggetacsopupgradesmod.entity.BeamEntity;
import net.mcreator.cickennuggetacsopupgradesmod.entity.BeamA14Entity;
import net.mcreator.cickennuggetacsopupgradesmod.entity.BeamA13Entity;
import net.mcreator.cickennuggetacsopupgradesmod.entity.BeamA12Entity;
import net.mcreator.cickennuggetacsopupgradesmod.entity.BeamA11Entity;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class BeamTickUpdatesProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			Entity entity = event.player;
			execute(event, entity.level, entity.getX(), entity.getY(), entity.getZ(), entity);
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if (entity.getPersistentData().getBoolean("beamA1") == true) {
			new Object() {
				private int ticks = 0;
				private float waitTicks;
				private LevelAccessor world;

				public void start(LevelAccessor world, int waitTicks) {
					this.waitTicks = waitTicks;
					MinecraftForge.EVENT_BUS.register(this);
					this.world = world;
				}

				@SubscribeEvent
				public void tick(TickEvent.ServerTickEvent event) {
					if (event.phase == TickEvent.Phase.END) {
						this.ticks += 1;
						if (this.ticks >= this.waitTicks)
							run();
					}
				}

				private void run() {
					if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
						BeamEntity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(), 2,
								(float) (2 + (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
										.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D1),
								0);
					}
					MinecraftForge.EVENT_BUS.unregister(this);
				}
			}.start(world, (int) (Math.random() + Math.random() + Math.random() + Math.random() + Math.random()));
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size1 == 1) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new BeamA11Entity(CickennuggetacsOpUpgradesModModEntities.BEAM_A_11, _level);
					entityToSpawn.moveTo(x, y, z, entity.getYRot(), entity.getXRot());
					entityToSpawn.setYBodyRot(entity.getYRot());
					entityToSpawn.setYHeadRot(entity.getYRot());
					entityToSpawn.setDeltaMovement(0, (y - 1), 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED,
								null, null);
					world.addFreshEntity(entityToSpawn);
				}
			}
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size1 == 2) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new BeamA12Entity(CickennuggetacsOpUpgradesModModEntities.BEAM_A_12, _level);
					entityToSpawn.moveTo(x, y, z, entity.getYRot(), entity.getXRot());
					entityToSpawn.setYBodyRot(entity.getYRot());
					entityToSpawn.setYHeadRot(entity.getYRot());
					entityToSpawn.setDeltaMovement(0, (y - 1), 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED,
								null, null);
					world.addFreshEntity(entityToSpawn);
				}
			}
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size1 == 3) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new BeamA13Entity(CickennuggetacsOpUpgradesModModEntities.BEAM_A_13, _level);
					entityToSpawn.moveTo(x, y, z, entity.getYRot(), entity.getXRot());
					entityToSpawn.setYBodyRot(entity.getYRot());
					entityToSpawn.setYHeadRot(entity.getYRot());
					entityToSpawn.setDeltaMovement(0, (y - 1), 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED,
								null, null);
					world.addFreshEntity(entityToSpawn);
				}
			}
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size1 == 4) {
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = new BeamA14Entity(CickennuggetacsOpUpgradesModModEntities.BEAM_A_14, _level);
					entityToSpawn.moveTo(x, y, z, entity.getYRot(), entity.getXRot());
					entityToSpawn.setYBodyRot(entity.getYRot());
					entityToSpawn.setYHeadRot(entity.getYRot());
					entityToSpawn.setDeltaMovement(0, (y - 1), 0);
					if (entityToSpawn instanceof Mob _mobToSpawn)
						_mobToSpawn.finalizeSpawn(_level, world.getCurrentDifficultyAt(entityToSpawn.blockPosition()), MobSpawnType.MOB_SUMMONED,
								null, null);
					world.addFreshEntity(entityToSpawn);
				}
			}
		}
	}
}
