package net.mcreator.cickennuggetacsopupgradesmod.procedures;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.common.MinecraftForge;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;

import net.mcreator.cickennuggetacsopupgradesmod.network.CickennuggetacsOpUpgradesModModVariables;
import net.mcreator.cickennuggetacsopupgradesmod.entity.FireS4Entity;
import net.mcreator.cickennuggetacsopupgradesmod.entity.FireS3Entity;
import net.mcreator.cickennuggetacsopupgradesmod.entity.FireS2Entity;
import net.mcreator.cickennuggetacsopupgradesmod.entity.FireS1Entity;

public class MagicKeybind1OnKeyPressedProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).m1 == 1) {
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).A1 == 1) {
				if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
						.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).T1 == 1) {
					if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size1 == 1) {
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).S1 * 20;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D1 * 15;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X1 * 35;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Y1 * 35;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size1 * 40;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							FireS1Entity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
									(float) ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).S1 * 0.3),
									(float) (2 + (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D1),
									(int) ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).S1 * 0.1));
						}
					}
					if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size1 == 2) {
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).S1 * 20;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D1 * 15;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X1 * 35;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Y1 * 35;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size1 * 40;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							FireS2Entity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
									(float) ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).S1 * 0.3),
									(float) (4 + (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D1),
									(int) ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).S1 * 0.1));
						}
					}
					if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size1 == 3) {
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).S1 * 20;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D1 * 15;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X1 * 35;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Y1 * 35;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size1 * 40;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							FireS3Entity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
									(float) ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).S1 * 0.3),
									(float) (8 + (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D1),
									(int) ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).S1 * 0.1));
						}
					}
					if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size1 == 4) {
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).S1 * 20;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D1 * 15;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X1 * 35;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Y1 * 35;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						{
							double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
									- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size1 * 40;
							entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
								capability.mana = _setval;
								capability.syncPlayerVariables(entity);
							});
						}
						if (entity instanceof LivingEntity _ent_sa && !_ent_sa.level.isClientSide()) {
							FireS4Entity.shoot(_ent_sa.level, _ent_sa, _ent_sa.level.getRandom(),
									(float) ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).S1 * 0.3),
									(float) (16 + (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D1),
									(int) ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
											.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).S1 * 0.1));
						}
					}
				}
			}
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).T1 == 2) {
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
							- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).S1 * 20;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.mana = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
							- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D1 * 15;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.mana = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
							- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X1 * 35;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.mana = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
							- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Y1 * 35;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.mana = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).mana
							- (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
									.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Size1 * 40;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.mana = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				entity.getPersistentData().putBoolean("beamA1", (true));
				new Object() {
					private int ticks = 0;
					private float waitTicks;
					private LevelAccessor world;

					public void start(LevelAccessor world, int waitTicks) {
						this.waitTicks = waitTicks;
						MinecraftForge.EVENT_BUS.register(this);
						this.world = world;
					}

					@SubscribeEvent
					public void tick(TickEvent.ServerTickEvent event) {
						if (event.phase == TickEvent.Phase.END) {
							this.ticks += 1;
							if (this.ticks >= this.waitTicks)
								run();
						}
					}

					private void run() {
						entity.getPersistentData().putBoolean("beamA1", (false));
						MinecraftForge.EVENT_BUS.unregister(this);
					}
				}.start(world, 100);
			}
		}
	}
}
