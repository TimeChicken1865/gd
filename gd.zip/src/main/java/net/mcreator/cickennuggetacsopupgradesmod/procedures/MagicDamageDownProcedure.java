package net.mcreator.cickennuggetacsopupgradesmod.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.cickennuggetacsopupgradesmod.network.CickennuggetacsOpUpgradesModModVariables;

public class MagicDamageDownProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).Damage > 0) {
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 1) {
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D1;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.Damage = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D1 - 1;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.D1 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 2) {
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D2;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.Damage = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D2 - 1;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.D2 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 3) {
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D3;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.Damage = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D3 - 1;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.D3 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 4) {
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D4;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.Damage = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D4 - 1;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.D4 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 5) {
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D5;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.Damage = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D5 - 1;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.D5 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 6) {
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D6;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.Damage = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).D6 - 1;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.D6 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
		}
	}
}
