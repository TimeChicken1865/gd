package net.mcreator.cickennuggetacsopupgradesmod.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.cickennuggetacsopupgradesmod.network.CickennuggetacsOpUpgradesModModVariables;

public class MagicXZUpProcedure {
	public static void execute(Entity entity) {
		if (entity == null)
			return;
		if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X1 < 40) {
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 1) {
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X1;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.XZ = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X1 + 1;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.X1 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 2) {
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X2;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.XZ = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X2 + 1;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.X1 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 3) {
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X3;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.XZ = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X3 + 1;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.X1 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 4) {
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X4;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.XZ = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X4 + 1;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.X1 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 5) {
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X5;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.XZ = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X5 + 1;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.X1 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 6) {
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X6;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.XZ = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
				{
					double _setval = (entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
							.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).X6 + 1;
					entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null).ifPresent(capability -> {
						capability.X1 = _setval;
						capability.syncPlayerVariables(entity);
					});
				}
			}
		}
	}
}
