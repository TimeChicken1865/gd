package net.mcreator.cickennuggetacsopupgradesmod.procedures;

import net.minecraft.world.entity.Entity;

import net.mcreator.cickennuggetacsopupgradesmod.network.CickennuggetacsOpUpgradesModModVariables;

public class A5Procedure {
	public static boolean execute(Entity entity) {
		if (entity == null)
			return false;
		if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 1) {
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).A1 == 5) {
				return true;
			}
		}
		if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 2) {
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).A2 == 5) {
				return true;
			}
		}
		if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 3) {
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).A3 == 5) {
				return true;
			}
		}
		if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 4) {
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).A4 == 5) {
				return true;
			}
		}
		if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 5) {
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).A5 == 5) {
				return true;
			}
		}
		if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
				.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).MagicKeybind == 6) {
			if ((entity.getCapability(CickennuggetacsOpUpgradesModModVariables.PLAYER_VARIABLES_CAPABILITY, null)
					.orElse(new CickennuggetacsOpUpgradesModModVariables.PlayerVariables())).A6 == 5) {
				return true;
			}
		}
		return false;
	}
}
