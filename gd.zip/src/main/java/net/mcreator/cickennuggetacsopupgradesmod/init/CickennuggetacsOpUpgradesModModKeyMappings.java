
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cickennuggetacsopupgradesmod.init;

import org.lwjgl.glfw.GLFW;

import net.minecraftforge.fmlclient.registry.ClientRegistry;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;

import net.mcreator.cickennuggetacsopupgradesmod.network.UpgradeMessage;
import net.mcreator.cickennuggetacsopupgradesmod.network.MagicKeybind1Message;
import net.mcreator.cickennuggetacsopupgradesmod.CickennuggetacsOpUpgradesModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class CickennuggetacsOpUpgradesModModKeyMappings {
	public static final KeyMapping UPGRADE = new KeyMapping("key.cickennuggetacs_op_upgrades_mod.upgrade", GLFW.GLFW_KEY_U, "key.categories.misc");
	public static final KeyMapping MAGIC_KEYBIND_1 = new KeyMapping("key.cickennuggetacs_op_upgrades_mod.magic_keybind_1", GLFW.GLFW_KEY_C,
			"key.categories.misc");

	@SubscribeEvent
	public static void registerKeyBindings(FMLClientSetupEvent event) {
		ClientRegistry.registerKeyBinding(UPGRADE);
		ClientRegistry.registerKeyBinding(MAGIC_KEYBIND_1);
	}

	@Mod.EventBusSubscriber({Dist.CLIENT})
	public static class KeyEventListener {
		@SubscribeEvent
		public static void onKeyInput(InputEvent.KeyInputEvent event) {
			if (Minecraft.getInstance().screen == null) {
				if (event.getKey() == UPGRADE.getKey().getValue()) {
					if (event.getAction() == GLFW.GLFW_PRESS) {
						CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new UpgradeMessage(0, 0));
						UpgradeMessage.pressAction(Minecraft.getInstance().player, 0, 0);
					}
				}
				if (event.getKey() == MAGIC_KEYBIND_1.getKey().getValue()) {
					if (event.getAction() == GLFW.GLFW_PRESS) {
						CickennuggetacsOpUpgradesModMod.PACKET_HANDLER.sendToServer(new MagicKeybind1Message(0, 0));
						MagicKeybind1Message.pressAction(Minecraft.getInstance().player, 0, 0);
					}
				}
			}
		}
	}
}
