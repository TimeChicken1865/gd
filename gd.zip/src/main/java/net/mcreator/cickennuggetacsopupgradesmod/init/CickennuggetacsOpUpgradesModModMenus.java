
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cickennuggetacsopupgradesmod.init;

import net.minecraftforge.fmllegacy.network.IContainerFactory;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.inventory.AbstractContainerMenu;

import net.mcreator.cickennuggetacsopupgradesmod.world.inventory.UpgradesMenu;
import net.mcreator.cickennuggetacsopupgradesmod.world.inventory.MagicMenu;
import net.mcreator.cickennuggetacsopupgradesmod.world.inventory.MagicCreation1Menu;

import java.util.List;
import java.util.ArrayList;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class CickennuggetacsOpUpgradesModModMenus {
	private static final List<MenuType<?>> REGISTRY = new ArrayList<>();
	public static final MenuType<UpgradesMenu> UPGRADES = register("upgrades", (id, inv, extraData) -> new UpgradesMenu(id, inv, extraData));
	public static final MenuType<MagicMenu> MAGIC = register("magic", (id, inv, extraData) -> new MagicMenu(id, inv, extraData));
	public static final MenuType<MagicCreation1Menu> MAGIC_CREATION_1 = register("magic_creation_1",
			(id, inv, extraData) -> new MagicCreation1Menu(id, inv, extraData));

	private static <T extends AbstractContainerMenu> MenuType<T> register(String registryname, IContainerFactory<T> containerFactory) {
		MenuType<T> menuType = new MenuType<T>(containerFactory);
		menuType.setRegistryName(registryname);
		REGISTRY.add(menuType);
		return menuType;
	}

	@SubscribeEvent
	public static void registerContainers(RegistryEvent.Register<MenuType<?>> event) {
		event.getRegistry().registerAll(REGISTRY.toArray(new MenuType[0]));
	}
}
