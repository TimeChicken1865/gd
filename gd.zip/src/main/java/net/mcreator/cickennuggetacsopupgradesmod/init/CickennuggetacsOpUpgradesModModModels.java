
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cickennuggetacsopupgradesmod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.cickennuggetacsopupgradesmod.client.model.ModelS4;
import net.mcreator.cickennuggetacsopupgradesmod.client.model.ModelS3;
import net.mcreator.cickennuggetacsopupgradesmod.client.model.ModelS2;
import net.mcreator.cickennuggetacsopupgradesmod.client.model.ModelFS1;
import net.mcreator.cickennuggetacsopupgradesmod.client.model.ModelBeam4;
import net.mcreator.cickennuggetacsopupgradesmod.client.model.ModelBeam3;
import net.mcreator.cickennuggetacsopupgradesmod.client.model.ModelBeam2;
import net.mcreator.cickennuggetacsopupgradesmod.client.model.ModelBeam;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = {Dist.CLIENT})
public class CickennuggetacsOpUpgradesModModModels {
	@SubscribeEvent
	public static void registerLayerDefinitions(EntityRenderersEvent.RegisterLayerDefinitions event) {
		event.registerLayerDefinition(ModelS2.LAYER_LOCATION, ModelS2::createBodyLayer);
		event.registerLayerDefinition(ModelBeam.LAYER_LOCATION, ModelBeam::createBodyLayer);
		event.registerLayerDefinition(ModelS3.LAYER_LOCATION, ModelS3::createBodyLayer);
		event.registerLayerDefinition(ModelBeam3.LAYER_LOCATION, ModelBeam3::createBodyLayer);
		event.registerLayerDefinition(ModelBeam2.LAYER_LOCATION, ModelBeam2::createBodyLayer);
		event.registerLayerDefinition(ModelBeam4.LAYER_LOCATION, ModelBeam4::createBodyLayer);
		event.registerLayerDefinition(ModelS4.LAYER_LOCATION, ModelS4::createBodyLayer);
		event.registerLayerDefinition(ModelFS1.LAYER_LOCATION, ModelFS1::createBodyLayer);
	}
}
