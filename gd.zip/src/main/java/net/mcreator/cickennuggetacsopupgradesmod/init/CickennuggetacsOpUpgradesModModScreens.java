
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.cickennuggetacsopupgradesmod.init;

import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.gui.screens.MenuScreens;

import net.mcreator.cickennuggetacsopupgradesmod.client.gui.UpgradesScreen;
import net.mcreator.cickennuggetacsopupgradesmod.client.gui.MagicScreen;
import net.mcreator.cickennuggetacsopupgradesmod.client.gui.MagicCreation1Screen;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class CickennuggetacsOpUpgradesModModScreens {
	@SubscribeEvent
	public static void clientLoad(FMLClientSetupEvent event) {
		event.enqueueWork(() -> {
			MenuScreens.register(CickennuggetacsOpUpgradesModModMenus.UPGRADES, UpgradesScreen::new);
			MenuScreens.register(CickennuggetacsOpUpgradesModModMenus.MAGIC, MagicScreen::new);
			MenuScreens.register(CickennuggetacsOpUpgradesModModMenus.MAGIC_CREATION_1, MagicCreation1Screen::new);
		});
	}
}
